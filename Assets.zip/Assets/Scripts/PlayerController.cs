using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using Unity.VisualScripting;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{

    bool canJump;
    
    // Start is called before the first frame update
    void Start(){
     
    }

    // Update is called once per frame
    void Update()
    {   
        if(Input.GetKey("left")){
            gameObject.GetComponent<Rigidbody2D>().AddForce(new UnityEngine.Vector2(-1000f * Time.deltaTime,0) );
        }

        if (Input.GetKey("right"))
        {
            gameObject.GetComponent<Rigidbody2D>().AddForce(new UnityEngine.Vector2(1000f * Time.deltaTime,0));
        }


        if(Input.GetKeyDown("up") && canJump)
        {
            canJump = false;
            gameObject.GetComponent<Rigidbody2D>().AddForce (new UnityEngine.Vector2(0, 100f));

        }
    
    }
  private  void OnCollisionEnter2D (Collision2D collision)
        {
            if(collision.transform.tag == "Ground" )
            {
                canJump = true;
            }


        }
    }
